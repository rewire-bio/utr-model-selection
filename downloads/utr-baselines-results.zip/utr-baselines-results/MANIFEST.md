# utr-baselines results archive

Evidence from the full comparison run described in the article "Choosing a model for 5′UTR translation experiments" and in `utr-baselines.zip` (the code archive). Everything here was produced by that code on 30 September 2026 on one Apple M4 laptop (16 GB, macOS 26.6.2, Python 3.11.13, torch 2.4.1), except the files under `receipts/parent/`. You can inspect every number in the article without rerunning the hour-long comparison.

## What is here

| Path | Contents |
|---|---|
| `run/metrics.json` | All test metrics for both splits: MSE (MRL²), MAE (MRL), R², Pearson and Spearman (null for the constant predictor), precision at 1% capacity, 95% cluster-bootstrap intervals, per-seed CNN results, paired comparisons and verdicts, per-sub-library and per-read-depth MSE, and the six declared-rule examples. |
| `run/prepare.json` | Input checks, split counts and hashes, dependence statistics (components, overlap share, ICC). |
| `run/embed.json` | UTR-LM checkpoint, known-answer check, embedding time, cache size, memory. |
| `run/failures.json` | Output of `describe_failures.py`: split composition by sub-library, the largest component, the concentrated CNN failure, CNN device-parity checks, per-seed CNN times, chance precision. |
| `run/verify.json` | Output of `verify.py` (independent recomputation; all checks passed). |
| `run/run-log.json`, `run/run-all.log` | Per-step wall times and hardware for `run-all`; console log with the printed summary. |
| `run/runs/<split>/<method>/fit.json` | Per-fit receipts: selected alpha or epochs, validation MSE, seconds, peak RSS, device, per-seed histories. |
| `run/runs/<split>/<method>/predictions.parquet` | Validation and test predictions, keyed by `source_index` (the row position in the pinned Hugging Face parquet) and `split`. CNN files have one column per seed. No sequences or labels. |
| `figures/` | The three charts (PNG and SVG), generated from `run/metrics.json` and the fit receipts by `make_figures.py`. |
| `receipts/protocol-registration.log`, `receipts/PROTOCOL-registered-*.md` | Registration timestamps and the protocol text as registered (08:56:32Z) and as amended before any test scoring (09:00:14Z). |
| `receipts/mps-vs-cpu-utrlm-receipt.txt` | CPU versus MPS output and masked-nucleotide accuracy for UTR-LM. |
| `receipts/environment-and-tests-receipt.txt` | RAM, CPU, OS, smoke timing, unit-test counts. |
| `receipts/notebook-execution.log` | Execution of `tutorial.ipynb` (230 s, MPS for smoke CNN fits). |
| `receipts/orthrus-install-attempt/` | The failed `mamba-ssm==1.2.0.post1` build (no nvcc on macOS). |
| `receipts/clean-room/` | Clean-environment rerun from the code archive, and its comparison with the original run (maximum prediction difference 0.0). |
| `receipts/parent/` | Independent mechanical checks by the parent Codex orchestration session: metric recomputation for all 22 method/split results, bootstrap depth reconstruction, statistics-helper checks, and a CPU-only smoke run. Automated checks, not human review. |

## Source data and redistribution

- No source datasets, model weights or embedding caches are included. The pinned mRNABench parquet, the GEO metadata and the UTR-LM checkpoint must be downloaded with `utr_baselines.py fetch`, which checks their SHA-256 hashes.
- Two small excerpts of source data are embedded. First, `run/metrics.json` shows six 50-nt inserts with their measured MRL, sub-library and read count (the declared-rule examples). Second, `run/prepare.json` includes the constant 780-nt eGFP tail shared by every processed sequence, which is also printed in the mRNABench code and the original paper. The Hugging Face dataset card gives the licence as "unknown"; these excerpts are kept for auditability and should be reviewed before public redistribution.
- Prediction files contain model outputs only. Recomputing metrics requires the labels from the pinned parquet.
- Local machine paths in the logs were replaced with `<workspace>`, `<home>`, `<series-control>` or `<tmp>`. Paths beginning `/Users/runner/` are PyTorch's own build paths inside its warning messages.
